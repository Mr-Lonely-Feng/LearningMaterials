### SparkSQL on HBase examples:

1. Example 1: Create and query SparkSQL table map to existing Hbase table
2. Example 2: Create and query SparkSQL table map to a new HBase table
3. Example 3: Similar to example 1, but with larger sample file
