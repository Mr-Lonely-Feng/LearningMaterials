#!/usr/bin/python
# -*- encoding:utf-8 -*-

if __name__ == '__main__':
    """
        Hello World 程序
    """
    print "hello world!!!!!!!!!!!!!!!"
