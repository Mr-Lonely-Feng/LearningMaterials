#!/usr/bin/python
# -*- encoding:utf-8 -*-

"""
@author: xuanyu
@contact: xuanyu@126.com
@file:.py
@time:2017/5/16 21:54
"""

# 导入模块 pyspark
from pyspark import SparkConf, SparkContext
# 导入系统模块
import os, time

if __name__ == '__main__':

    # 设置SPARK_HOME环境变量
    os.environ['SPARK_HOME'] = 'E:/spark-1.6.1-bin-2.5.0-cdh5.3.6'
    os.environ['HADOOP_HOME'] = 'G:/OnlinePySparkCourse/pyspark-project/winuntil'

    # Create SparkConf
    sparkConf = SparkConf()\
        .setAppName('Python Spark WordCount')\
        .setMaster('local[2]')

    # Create SparkContext
    sc = SparkContext(conf=sparkConf)
    # 设置日志级别
    sc.setLogLevel('WARN')

    """
        创建RDD
            方式一：从本地集合进行并行化创建
            方式二：从外部文件系统读取数据（HDFS，Local）
    """
    # 第一种方式：从集合并行化创建RDD
    # 列表list
    datas = ['hadoop spark', 'spark hive spark sql', 'spark hadoop sql sql spark']
    # Create RDD
    rdd = sc.parallelize(datas)

    # 测试, 获取总数count及第一条数据
    print rdd.count()
    print rdd.first()

    # ===============================================================
    # 词频统计，针对SCALA编程 flatMap\map\reduceByKey
    word_count_rdd = rdd\
        .flatMap(lambda line: line.split(" "))\
        .map(lambda word: (word, 1))\
        .reduceByKey(lambda a, b: a + b)
    # output
    for x in word_count_rdd.collect():
        print x[0] + ", " + str(x[1])

    # WEB UI 4040, 让线程休眠一段时间
    time.sleep(100000)

    # SparkContext Stop
    sc.stop()
